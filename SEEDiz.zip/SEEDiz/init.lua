dofile("data/scripts/game_helpers.lua")
dofile_once("data/scripts/lib/utilities.lua")
dofile_once("data/scripts/lib/coroutines.lua")

-- SEE DEEZ NUTS
function OnPlayerSpawned( player_entity ) 
	local seed = tonumber(StatsGetValue("world_seed"))
	f = io.open("mods/SEEDiz/data/current_seed.txt", "w")
    io.output(f)
	f:write(seed)
	f:close()
end

